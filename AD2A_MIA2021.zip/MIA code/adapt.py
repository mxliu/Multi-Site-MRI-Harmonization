import torch
from torch import nn
from torch.utils.data import DataLoader
import torch.nn.functional as F
from torch.utils.data.sampler import SubsetRandomSampler
import numpy as np
import os
from torchvision.transforms import Compose, ToTensor
from tqdm import tqdm
import model
from utils import loop_iterable, set_requires_grad 
from utils import GradientReversal,loop_iterable
import dataset


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
MODEL_FILE = 'source.pt'
net = model.Net(dropout=0.5)
net.to(device)
net.load_state_dict(torch.load(MODEL_FILE))
feature_extractor = net.feature_extractor
clf = net.classifier

discriminator = nn.Sequential(
    GradientReversal(lambda_= 0.1),
    nn.Linear(256, 128), 
    nn.ReLU(), 
    nn.Linear(128, 64), 
    nn.ReLU(), 
    nn.Linear(64, 1)
).to(device)

optimizer = torch.optim.Adam(list(discriminator.parameters()) + list(net.parameters()),lr=0.0001)
batch_size = 4
half_batch = batch_size // 2
source_path = os.path.join(".","Data/source.dat") 
target_path = os.path.join(".","Data/target.dat") 

source_dataset = dataset.MyDataset(data_path = source_path)
source_loader = torch.utils.data.DataLoader(source_dataset, half_batch, shuffle=True)
target_dataset = dataset.MyDataset(data_path = target_path)
target_loader = torch.utils.data.DataLoader(target_dataset, half_batch, shuffle=True)


def do_epoch(model, source_loader, target_loader, optim = None):
    batches = zip(source_loader, target_loader)
    n_batches = min(len(source_loader), len(target_loader))
    total_loss = 0
     
    for (source_x, source_labels), (target_x, _) in tqdm(batches, leave=False, total=n_batches):
       x = torch.cat([source_x, target_x])
       x = x.to(device)    
       domain_y = torch.cat([torch.ones(source_x.shape[0]),torch.zeros(target_x.shape[0])])
       domain_y = domain_y.to(device)   
       label_y = source_labels.to(device)
       features = feature_extractor(x).view(x.shape[0], -1)    
       domain_preds = discriminator(features).squeeze()
       label_preds = clf(features[:source_x.shape[0]])            
       domain_loss = F.binary_cross_entropy_with_logits(domain_preds, domain_y)
       label_loss = F.cross_entropy(label_preds, label_y)     
       attention = net.SpatialGate.attention.squeeze()
       s = attention[:2,:,:,:]
       t = attention[2:,:,:,:]
       delta = s-t
       att_loss = 0.5* (delta[0].pow(2).sum() + delta[1].pow(2).sum())/(2*200*200*200)       
       loss =  label_loss + domain_loss + att_loss
       if optim is not None:
           optim.zero_grad()
           loss.backward() 
           optim.step()        
       total_loss += loss.item()
    mean_loss = total_loss / n_batches
    return mean_loss

for epoch in range(1, 51):
    net.train()
    train_loss = do_epoch(net, source_loader, target_loader, optim = optimizer)
    tqdm.write(f'Epoch {epoch:03d}: train_loss = {train_loss:.4f}----')
    torch.save(net.state_dict(), 'trained_net.pt')