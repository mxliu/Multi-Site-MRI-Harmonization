import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data.sampler import SubsetRandomSampler
import torchvision.transforms as transforms
import numpy as np
import os
from time import time
from tqdm import tqdm
import dataset
from model import Net


data_path = os.path.join(".","Data/source.dat")

dataset = dataset.MyDataset(data_path = data_path)

shuffled_indices = np.random.permutation(len(dataset))
train_idx = shuffled_indices[ :int(0.8 *len(dataset))]
val_idx = shuffled_indices[int(0.8*len(dataset)): ]

train_loader = torch.utils.data.DataLoader(dataset, batch_size= 2, drop_last = True,
                                          sampler=SubsetRandomSampler(train_idx) ) 
    
val_loader = torch.utils.data.DataLoader(dataset, batch_size= 2, drop_last = False,
                            sampler=SubsetRandomSampler(val_idx) )

print('data loading done...\n')

net = Net(dropout=0.5)
print(net)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)
net.to(device)

optimizer = torch.optim.Adam(net.parameters(), lr=0.0001)    
loss_function = nn.CrossEntropyLoss()

def do_epoch(model, dataloader, criterion, optim = None):

    total_loss = 0
    for x, y_true in tqdm(dataloader):
        x, y_true = x.to(device), y_true.to(device)
        y_pred = model(x)
        loss = criterion(y_pred, y_true)

        if optim is not None:
            optim.zero_grad()
            loss.backward() 
            optim.step()
            
        total_loss += loss.item()
    mean_loss = total_loss / len(dataloader)
    return mean_loss

best_loss = 100000
for epoch in range(1, 31):
    net.train()
    train_loss = do_epoch(net, train_loader, loss_function, optim = optimizer)

    net.eval()
    with torch.no_grad():
        val_loss = do_epoch(net, val_loader, loss_function, optim = None)

    tqdm.write(f'Epoch {epoch:03d}: train_loss = {train_loss:.4f} ---'
               f'val_loss = {val_loss: .4f}')
    
    if val_loss < best_loss:
        print('saving model...')
        best_loss = val_loss
        torch.save(net.state_dict(), 'source.pt')

correct = 0
total = 0
with torch.no_grad():  
    for images, labels in tqdm(val_loader):
        images = images.to(device)
        labels = labels.to(device)    
        outputs = net(images)
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()  
        
print('Accuracy on the val set: %d %%' %(100 * correct / total))     