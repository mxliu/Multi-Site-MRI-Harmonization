import torch
import torch.nn.functional as F
import numpy as np
import scipy.io as sio
import os
import dataset
from model import Net
from tqdm import tqdm


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)
data_path = os.path.join(".","Datalist/test.dat") 
dataset = dataset.MyDataset(data_path = data_path)
dataloader_target = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)     

MODEL_FILE = 'trained_net.pt'
net = Net()
net.to(device)
net.load_state_dict(torch.load(MODEL_FILE))
net.eval()
print('Test a model on the target domain...')
correct = 0
total = 0

with torch.no_grad():  
    for images, labels in tqdm(dataloader_target):
        images = images.to(device)
        labels = labels.to(device)
        
        outputs = net(images)
        _, predicted = torch.max(outputs.data, 1)
        
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
        
print('Accuracy on the target domain: %.4f %%' %(100 * correct / total))