
import torch
from torchvision import datasets
import numpy as np
import scipy.io as sio
from PIL import Image
from torch.utils.data import Dataset, DataLoader
import os


class MyDataset(Dataset):
    def __init__(self, data_path, transform = None):
        fh = open(data_path, 'r')
        imgs = []
        for line in fh:
            line = line.rstrip() 
            words = line.split()
            imgs.append( (words[0], int(words[1])) )
            self.imgs = imgs
            self.transform = transform
                      
        
    def __getitem__(self, index):   
        fn, label = self.imgs[index]
        img_dict = sio.loadmat(fn)
        img = img_dict['IMG']
        img = img.astype('float32')
        img = img/255
        img = np.expand_dims(img, axis = 0)
        
        return img, label
    
    
    def __len__(self):
        return len(self.imgs)